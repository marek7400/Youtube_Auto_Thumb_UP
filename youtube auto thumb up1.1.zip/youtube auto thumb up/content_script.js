let observer = null;
let poller = null; // Zmienna przechowująca ID interwału
let isProcessing = false;
/**
Wyświetla powiadomienie "Auto Thumb UP" na środku ekranu.
*/
function showThumbUpNotification() {
if (document.getElementById('auto-thumb-up-notification')) return;
const notificationDiv = document.createElement('div');
notificationDiv.id = 'auto-thumb-up-notification';
Object.assign(notificationDiv.style, {
position: 'fixed',
top: '50%',
left: '50%',
transform: 'translate(-50%, -50%) scale(0.8)',
backgroundColor: 'rgba(220, 53, 69, 0.95)',
color: 'white',
padding: '20px 30px',
borderRadius: '12px',
zIndex: '99999',
display: 'flex',
alignItems: 'center',
fontSize: '20px',
fontFamily: 'YouTube Sans, Roboto, Arial, sans-serif',
boxShadow: '0 8px 16px rgba(0,0,0,0.4)',
opacity: '0',
transition: 'opacity 0.3s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)'
});
const icon = document.createElement('img');
icon.src = chrome.runtime.getURL('icons/thumb_up_icon.svg');
Object.assign(icon.style, {
width: '28px',
height: '28px',
marginRight: '15px'
});
const text = document.createElement('span');
text.textContent = 'Auto Thumb UP';
notificationDiv.appendChild(icon);
notificationDiv.appendChild(text);
document.body.appendChild(notificationDiv);
setTimeout(() => {
notificationDiv.style.opacity = '1';
notificationDiv.style.transform = 'translate(-50%, -50%) scale(1)';
}, 10);
setTimeout(() => {
notificationDiv.style.opacity = '0';
notificationDiv.style.transform = 'translate(-50%, -50%) scale(0.8)';
setTimeout(() => notificationDiv.remove(), 300);
}, 3000);
}
/**
Aktywnie szuka przycisków po znalezieniu kontenera metadanych i wykonuje akcję.
@param {object} settings - Ustawienia rozszerzenia.
*/
function findAndClickButtons(settings) {
if (poller) {
clearInterval(poller);
}
let attempts = 0;
const maxAttempts = 40; // 40 * 250ms = 10 sekund
const pollInterval = 250;
poller = setInterval(() => {
attempts++;

// Używamy selektora, który potwierdziłeś jako działający
 const likeButton = document.querySelector('ytd-watch-metadata #top-level-buttons-computed like-button-view-model button');
 const subscribeButton = document.querySelector('ytd-watch-metadata ytd-subscribe-button-renderer');

 if (likeButton && subscribeButton) {
     clearInterval(poller);

     const isSubscribed = subscribeButton.hasAttribute('subscribed');

     if (!isSubscribed) {
         console.log('[Auto Thumb UP] Kanał nie jest subskrybowany. Akcja pominięta.');
         isProcessing = false;
         return;
     }
     
     console.log('[Auto Thumb UP] Kanał subskrybowany, przyciski znalezione.');

     if (likeButton.getAttribute('aria-pressed') !== 'true') {
         console.log('[Auto Thumb UP] Klikanie przycisku "Podoba mi się".');
         likeButton.click();
         if (settings.showInfo) {
             setTimeout(() => showThumbUpNotification(), 250);
         }
     } else {
         console.log('[Auto Thumb UP] Film jest już polubiony.');
     }
     isProcessing = false;
 } else if (attempts >= maxAttempts) {
     clearInterval(poller);
     console.error(`[Auto Thumb UP] Nie znaleziono przycisków po ${maxAttempts * pollInterval / 1000} sekundach.`);
     isProcessing = false;
 }

}, pollInterval);
}
/**
Główna funkcja inicjująca proces na stronie.
*/
function processPage() {
if (isProcessing) return;
isProcessing = true;
if (observer) observer.disconnect();
if (poller) clearInterval(poller);
chrome.storage.sync.get(['autoThumbUp', 'showInfo'], (settings) => {
if (!settings.autoThumbUp) {
console.log('[Auto Thumb UP] Funkcja wyłączona w ustawieniach.');
isProcessing = false;
return;
}

// Czekamy na pojawienie się kontenera ytd-watch-metadata, który zawiera wszystkie przyciski
 observer = new MutationObserver((mutations, obs) => {
     if (document.querySelector("ytd-watch-metadata")) {
         console.log('[Auto Thumb UP] Wykryto kontener metadanych. Rozpoczynam wyszukiwanie przycisków.');
         obs.disconnect(); // Znaleziono kontener, wyłączamy obserwatora
         findAndClickButtons(settings);
     }
 });

 observer.observe(document.body, {
     childList: true,
     subtree: true
 });
});
}
// Nasłuchiwanie wiadomości z background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
if (request.type === 'NEW_VIDEO_PAGE') {
console.log('[Auto Thumb UP] Wykryto nawigację do nowego filmu. Uruchamianie skryptu.');
processPage();
}
return true;
});
// Uruchomienie skryptu przy pierwszym załadowaniu strony
processPage();