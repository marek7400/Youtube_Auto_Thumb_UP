// Funkcja aktualizująca plakietkę na ikonie rozszerzenia
function updateBadge(isEnabled) {
const badgeText = isEnabled ? 'ON' : '';
chrome.action.setBadgeText({ text: badgeText });
if (isEnabled) {
// Ustawienie tła plakietki na zielony, gdy funkcja jest włączona
chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
}
}
// Ustawienie początkowego stanu plakietki przy starcie przeglądarki
chrome.runtime.onStartup.addListener(() => {
chrome.storage.sync.get('autoThumbUp', ({ autoThumbUp }) => {
updateBadge(!!autoThumbUp);
});
});
// Ustawienie początkowego stanu plakietki zaraz po instalacji (i ustawienie wartości domyślnej)
chrome.runtime.onInstalled.addListener(() => {
chrome.storage.sync.get('autoThumbUp', (result) => {
// Jeśli wartość nie jest ustawiona, ustaw ją domyślnie na true
if (typeof result.autoThumbUp === 'undefined') {
chrome.storage.sync.set({ autoThumbUp: true, showInfo: true }, () => {
updateBadge(true);
});
} else {
updateBadge(!!result.autoThumbUp);
}
});
});
// Nasłuchiwanie zmian w chrome.storage
chrome.storage.onChanged.addListener((changes, namespace) => {
if (namespace === 'sync' && changes.autoThumbUp) {
const isEnabled = !!changes.autoThumbUp.newValue;
updateBadge(isEnabled);
}
});
// Nasłuchiwanie zmian w historii nawigacji w celu wykrycia nawigacji po stronie YouTube
// To jest bardziej niezawodne dla aplikacji jednostronicowych (SPA) jak YouTube
chrome.webNavigation.onHistoryStateUpdated.addListener((details) => {
// Sprawdzamy, czy URL pasuje do strony z filmem na YouTube
if (details.url && details.url.includes("https://www.youtube.com/watch?v=")) {
// Wysyłamy wiadomość do skryptu treści na tej karcie
chrome.tabs.sendMessage(details.tabId, { type: "NEW_VIDEO_PAGE" });
}
}, {
url: [{ hostContains: 'www.youtube.com' }]
});