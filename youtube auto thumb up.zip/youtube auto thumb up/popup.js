document.addEventListener('DOMContentLoaded', () => {
    const autoThumbUpCheckbox = document.getElementById('autoThumbUp');
    const showInfoCheckbox = document.getElementById('showInfo');

    // Load saved settings and set the state of the checkboxes
    chrome.storage.sync.get(['autoThumbUp', 'showInfo'], (result) => {
        autoThumbUpCheckbox.checked = !!result.autoThumbUp;
        showInfoCheckbox.checked = !!result.showInfo;
    });

    // Save the state change for "Auto Thumb UP"
    autoThumbUpCheckbox.addEventListener('change', () => {
        chrome.storage.sync.set({ autoThumbUp: autoThumbUpCheckbox.checked });
    });

    // Save the state change for "Show notification"
    showInfoCheckbox.addEventListener('change', () => {
        chrome.storage.sync.set({ showInfo: showInfoCheckbox.checked });
    });
});