// Global variable to store the ID of the last processed video.
// This prevents the script from running multiple times on the same page.
let processedVideoId = null;

/**
 * Gets the unique video ID from the current URL.
 * @returns {string|null} The video ID or null if not found.
 */
function getVideoId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('v');
}

/**
 * Displays an "Auto Thumb UP" notification in the center of the screen.
 */
function showThumbUpNotification() {
    // Prevent creating multiple notifications
    if (document.getElementById('auto-thumb-up-notification')) return;

    const notificationDiv = document.createElement('div');
    notificationDiv.id = 'auto-thumb-up-notification';

    // *** STYLE AND DURATION CHANGES ***
    // Styles for the notification, now centered with red background.
    Object.assign(notificationDiv.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%) scale(0.8)',
        backgroundColor: 'rgba(220, 53, 69, 0.95)', // Red background
        color: 'white', // White text
        padding: '20px 30px',
        borderRadius: '12px',
        zIndex: '99999',
        display: 'flex',
        alignItems: 'center',
        fontSize: '20px',
        fontFamily: 'YouTube Sans, Roboto, Arial, sans-serif',
        boxShadow: '0 8px 16px rgba(0,0,0,0.4)',
        opacity: '0',
        transition: 'opacity 0.3s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)'
    });

    const icon = document.createElement('img');
    icon.src = chrome.runtime.getURL('icons/thumb_up_icon.svg');
    Object.assign(icon.style, {
        width: '28px',
        height: '28px',
        marginRight: '15px'
    });
    
    const text = document.createElement('span');
    text.textContent = 'Auto Thumb UP';

    notificationDiv.appendChild(icon);
    notificationDiv.appendChild(text);
    document.body.appendChild(notificationDiv);

    // Fade-in animation
    setTimeout(() => {
        notificationDiv.style.opacity = '1';
        notificationDiv.style.transform = 'translate(-50%, -50%) scale(1)';
    }, 10);

    // Fade-out animation and removal after 3 seconds (was 2)
    setTimeout(() => {
        notificationDiv.style.opacity = '0';
        notificationDiv.style.transform = 'translate(-50%, -50%) scale(0.8)';
        setTimeout(() => notificationDiv.remove(), 300); // Remove after animation ends
    }, 3000); // DURATION INCREASED TO 3 SECONDS
}


/**
 * Main logic function. Finds buttons, checks settings, and performs actions.
 * @param {MutationObserver} observer - The observer instance that can be disconnected.
 */
function processVideoPage(observer) {
    const currentVideoId = getVideoId();

    if (!currentVideoId || currentVideoId === processedVideoId) {
        if (observer) observer.disconnect();
        return;
    }

    const notificationBell = document.querySelector('ytd-subscribe-button-renderer yt-animated-icon[animated-icon-type="NOTIFICATION_BELL"]');
    const subscribeButton = document.querySelector('#subscribe-button button.yt-spec-button-shape-next--filled');

    if (!notificationBell && !subscribeButton) {
        return; 
    }

    if (observer) {
        console.log('[Extension] Key elements found. Observer is stopping for this page.');
        observer.disconnect();
    }
    
    processedVideoId = currentVideoId;

    chrome.storage.sync.get(['autoThumbUp', 'showInfo'], (settings) => {
        if (!settings.autoThumbUp) {
            console.log(`[Extension] Video ${currentVideoId}: "Auto Thumb UP" feature is disabled.`);
            return;
        }

        if (notificationBell) {
            console.log(`[Extension] Video ${currentVideoId}: Channel is subscribed. Checking 'Like' button.`);
            
            const likeButtonSelector = "#top-level-buttons-computed > segmented-like-dislike-button-view-model > yt-smartimation > div > div > like-button-view-model > toggle-button-view-model > button-view-model > button";
            const likeButton = document.querySelector(likeButtonSelector);

            if (likeButton) {
                if (likeButton.getAttribute('aria-pressed') !== 'true') {
                    console.log(`[Extension] Video ${currentVideoId}: Clicking 'Like' button.`);
                    likeButton.click();
                    
                    if (settings.showInfo) {
                        setTimeout(() => {
                             console.log(`[Extension] Video ${currentVideoId}: Displaying notification.`);
                             showThumbUpNotification();
                        }, 100);
                    }
                } else {
                    console.log(`[Extension] Video ${currentVideoId}: Already liked.`);
                }
            } else {
                 console.log(`[Extension] Video ${currentVideoId}: Like button not found.`);
            }
        } else {
            console.log(`[Extension] Video ${currentVideoId}: Channel is not subscribed.`);
        }
    });
}

// --- MutationObserver Setup ---
function startObserver() {
    const observer = new MutationObserver((mutations, obs) => {
        processVideoPage(obs);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
    console.log('[Extension] Observer started, watching for page changes.');
}

// Listen for URL changes to re-trigger the logic on new pages (crucial for SPAs like YouTube)
let lastUrl = location.href; 
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    processedVideoId = null;
    console.log(`[Extension] URL changed to: ${url}. Resetting state and starting new observer.`);
    startObserver();
  }
}).observe(document, { subtree: true, childList: true });

// Initial run
startObserver();