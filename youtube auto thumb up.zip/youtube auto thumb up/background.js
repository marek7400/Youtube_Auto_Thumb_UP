// Function to update the badge on the extension icon
function updateBadge(isEnabled) {
    const badgeText = isEnabled ? 'ON' : '';
    chrome.action.setBadgeText({ text: badgeText });
    if (isEnabled) {
        // Set the badge background color to green when the feature is enabled
        chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
    }
}

// Set the initial badge state on browser startup
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.sync.get('autoThumbUp', ({ autoThumbUp }) => {
        updateBadge(!!autoThumbUp);
    });
});

// Set the initial badge state right after installation (and set a default value)
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.get('autoThumbUp', (result) => {
        // If the value is not set, set it to true as a default
        if (typeof result.autoThumbUp === 'undefined') {
            chrome.storage.sync.set({ autoThumbUp: true }, () => {
                updateBadge(true);
            });
        } else {
            updateBadge(!!result.autoThumbUp);
        }
    });
});


// Listen for changes in chrome.storage
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.autoThumbUp) {
        const isEnabled = !!changes.autoThumbUp.newValue;
        updateBadge(isEnabled);
    }
});